import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';


function Page404() {
    return(  <div className="container">404</div>)
}
export  default  Page404