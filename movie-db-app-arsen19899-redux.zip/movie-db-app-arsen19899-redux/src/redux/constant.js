export const BASE_PATH = 'https://api.themoviedb.org/3/';
export const POPUL ='movie/popular?';
export const SEARCH_PATH = 'search/movie?';
export const SEARCH_PARAM = 'query=';
export const API_KEY='api_key=b9f7a0ee130480f6cd231acd274b0daa';
export const PAGE_PARAM = 'page=';
export const PRE_FIX ='movie/';